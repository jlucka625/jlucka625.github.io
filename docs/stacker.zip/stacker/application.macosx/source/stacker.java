import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class stacker extends PApplet {

class Stacker
{
    //properties
    int level, length, x, y, frameCounter, direction, gHeight, gWidth, damping;
    int initX, initY, initLength, initLevel;
    int[][] grid;
    boolean levelComplete;
    int c1, c2;
    
    //constructor
    Stacker(int level, int length, int gWidth, int gHeight, int damping, int c1, int c2)
    {
        this.level = level;
        this.length = length;
        this.gWidth = gWidth;
        this.gHeight = gHeight;
        this.damping = damping;
        this.c1 = c1;
        this.c2 = c2;
        x = 100;
        y = (gHeight * 50) - 50;
        frameCounter = 0;
        direction = 1;
        
        initX = x;
        initY = y;
        initLength = length;
        initLevel = level;
        
        levelComplete = false;
        
        setupGrid();
    }
    
    //layout the grid values
    public void setupGrid()
    {
        grid = new int[gWidth][gHeight];
        for(int i = 0; i < gWidth; i++)
        {
            for(int j = 0; j < gHeight; j++)
            {
                grid[i][j] = 0;
            }
        }
    }
    
    public void drawBackground()
    {
        for(int i = 0; i < gWidth; i++)
        {
            for(int j = 0; j < gHeight; j++)
            {
                if(grid[i][j] == 0)
                  fill(c1);
                else
                  fill(c2);
                
                rect(50 * i, 50 * j, 50, 50);
            }
        }   
    }
    
    public void update()
    {
        //adjusting speed and direction of blocks according to level
        if(level != 0)
        {
            if((frameCounter) % (level * damping) == 0)
                x += direction * 50;  
            if(x + length * 50 >= width)
               direction = -1;
            else if(x <= 0)
               direction = 1; 
        }
        else //reset evething if player passes final level
        {
            for(int i = 0; i < gWidth; i++)
            {
                for(int j = 0; j < gHeight; j++)
                {     
                    grid[i][j] = 0;
                    length = initLength;
                    level = initLevel;
                    x = initX;
                    y = initY;
                }
            }
            levelComplete = true;     
        }
        
        //reset everything if player loses
        //Loss signified by having no blocks left
        if(length == 0)
        {
            for(int i = 0; i < gWidth; i++)
            {
                for(int j = 0; j < gHeight; j++)
                {     
                    grid[i][j] = 0;
                    length = initLength;
                    level = initLevel;
                    x = initX;
                    y = initY;
                }
            }
        }
        drawBackground();
        //move blocks
        for(int tempX = x; tempX < x + (50 * length); tempX += 50)
        {
           fill(c2);
           rect(tempX, y, 50, 50); 
        }
        //update frame count
        frameCounter++;
        
        //update amount of blocks as level increases
        int twoBlock = initLevel - initLevel/3;
        int oneBlock = twoBlock - initLevel/3;
        if(level == twoBlock  && length == 3)
        {
           length = 2; 
        }
        else if(level == oneBlock && length == 2)
        {
           length = 1; 
        }
    }
    
    public void advance()
    {
        checkUnder();
        for(int tempX = x; tempX < x + (50 * length); tempX += 50)
        {
          grid[tempX/50][y/50] = 1;
        }
        y -= 50; 
        level--;
    }
    
    public void checkUnder()
    {
        int i, j;
        int c = x + (50 * length);
        for(int tempX = x; tempX < c; tempX += 50)
        {
            i = tempX/50;
            j = y/50;
            if(level <= initLevel - 1)
                if(grid[i][j + 1] == 0)
                    if(length != 0)
                    {
                        if(tempX == x)
                            x += 50;
                        else if(tempX == c)
                            x -= 50;
                        length--;
                    }
                    else length = 0;         
        }      
    }
}

Stacker s;
int levelCount = 0;
public void setup()
{
    size(300, 400);
    int c1 = color(150, 150, 150);
    int c2 = color(255, 0, 255);
    s = new Stacker(height/50, 3, width/50, height/50, 4, c1, c2);
    frame.setResizable(true);
}
public void draw()
{
   int c1, c2;
   s.update(); 
   if(s.levelComplete)
   {
       levelCount++; 
       switch(levelCount)
       {
           case 1: frame.setSize(500, 520);
                   c1 = color(50, 50, 50);
                   c2 = color(255, 255, 0);
                   s = new Stacker(10, 3, 10, 10, 3, c1, c2);  
                   break;
           case 2: frame.setSize(350, 570);
                   c1 = color(255, 255, 255);
                   c2 = color(0, 0, 0);
                   s = new Stacker(11, 3, 7, 11, 2, c1, c2);  
                   break;
           case 3: frame.setSize(450, 520);
                   c1 = color(0, 255, 255);
                   c2 = color(255, 0, 0);
                   s = new Stacker(10, 2, 9, 10, 2, c1, c2);  
                   break;
           case 4: frame.setSize(250, 570);
                   c1 = color(0, 0, 0);
                   c2 = color(0, 0, 255);
                   s = new Stacker(11, 1, 5, 11, 1, c1, c2);  
                   break;
       }      
   }
}
public void mousePressed()
{
   s.advance(); 
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "stacker" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
